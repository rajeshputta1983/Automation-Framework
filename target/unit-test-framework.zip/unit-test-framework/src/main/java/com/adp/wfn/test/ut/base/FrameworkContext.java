package com.adp.wfn.test.ut.base;

import java.util.HashMap;

/*
 * @author Rajesh Putta
 */
public class FrameworkContext {
	private static final FrameworkContext singleton=new FrameworkContext();
	private ThreadLocal<HashMap<String, Object>> context=new ThreadLocal<HashMap<String, Object>>();
	
	private FrameworkContext(){
		this.context.set(new HashMap<String, Object>(2<<2));
	}
	
	public static FrameworkContext getInstance() {
		return singleton;
	}
	
	public void put(String key, Object value) {
		this.context.get().put(key, value);
	}
	
	public Object get(String key) {
		return this.context.get().get(key);
	}

	public Object remove(String key) {
		return this.context.get().remove(key);
	}
}
