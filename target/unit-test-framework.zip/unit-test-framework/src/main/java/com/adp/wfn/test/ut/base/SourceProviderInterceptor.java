package com.adp.wfn.test.ut.base;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

/*
 * @author Rajesh Putta
 */
public class SourceProviderInterceptor implements MethodInterceptor {
	
	public Object invoke(MethodInvocation invocation) throws Throwable {

		Class<ISourceProvider> providerClass = invocation.getMethod().getAnnotation(Source.class).provider();
		// create instance of provider class and invocation handler class 
		System.out.println("before invoking method..."+invocation.getMethod().getName());
		return invocation.proceed();
	}
}
