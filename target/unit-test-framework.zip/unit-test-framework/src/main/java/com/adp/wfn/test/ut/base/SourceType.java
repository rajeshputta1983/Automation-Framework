package com.adp.wfn.test.ut.base;

/*
 * @author Rajesh Putta
 */
public enum SourceType {
	CSV, Map
}
