package com.adp.wfn.test.ut.base;

import java.util.Set;

import org.reflections.Reflections;

import com.google.inject.AbstractModule;
import com.google.inject.matcher.Matchers;

/*
 * @author Rajesh Putta
 */
public class UnitTestGuiceModule extends AbstractModule {

	@Override
	protected void configure() {
		SourceProviderInterceptor sourceProviderInterceptor = new SourceProviderInterceptor();
		
		bindInterceptor(
	            Matchers.any(),
	            Matchers.annotatedWith(Source.class),
	            sourceProviderInterceptor);

		Reflections reflections = new Reflections("com.adp.wfn.");
		Set<Class<?>> testClasses = reflections.getTypesAnnotatedWith(TestClass.class);
		
		if(testClasses!=null && !testClasses.isEmpty()) {
			// register all test classes with guice framework
			for(Class<?> testClass: testClasses) {
				bind(testClass);
			}
		}
	}
	
}
