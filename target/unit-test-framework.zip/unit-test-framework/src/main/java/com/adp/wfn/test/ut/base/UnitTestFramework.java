package com.adp.wfn.test.ut.base;

import com.google.inject.Guice;
import com.google.inject.Injector;

/*
 * @author Rajesh Putta
 */
public class UnitTestFramework {
	private static final UnitTestFramework singleton=new UnitTestFramework();
	private Injector injector=null;
	
	private UnitTestFramework() {
	}
	
	public static UnitTestFramework getInstance() {
		return singleton;
	}
	
	public void initialize() {
		this.injector = Guice.createInjector(new UnitTestGuiceModule());
	}
	
	public <T> T getTestClass(Class<T> clazz) {
		return this.injector.getInstance(clazz);
	}
}
