package com.adp.wfn.test.ut.base;

import com.test.ServiceTester;

public class FrameworkTester {

	public static void main(String[] args) {
		UnitTestFramework framework=UnitTestFramework.getInstance();
		framework.initialize();
		
		ServiceTester tester=framework.getTestClass(ServiceTester.class);
		tester.testEmployeeService();
	}

}
