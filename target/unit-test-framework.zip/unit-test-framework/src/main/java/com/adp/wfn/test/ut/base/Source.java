package com.adp.wfn.test.ut.base;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/*
 * @author Rajesh Putta
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Source {
	Class<ISourceProvider> provider();
	Class<InvocationHandler> invocationHandler();
	String[] params = null;
}
