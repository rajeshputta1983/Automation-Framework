package com.adp.wfn.test.ut.base;

/*
 * @author Rajesh Putta
 */
public interface InvocationHandler {
	
}
