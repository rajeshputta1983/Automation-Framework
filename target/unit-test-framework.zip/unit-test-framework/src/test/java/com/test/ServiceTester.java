package com.test;

import com.adp.wfn.test.ut.base.ISourceProvider;
import com.adp.wfn.test.ut.base.InvocationHandler;
import com.adp.wfn.test.ut.base.Source;
import com.adp.wfn.test.ut.base.TestClass;

@TestClass
public class ServiceTester {
	
	@Source(provider=ISourceProvider.class, invocationHandler=InvocationHandler.class)
	public void testEmployeeService() {
		System.out.println("hello inside test method...");
	}
}
